def my_function(text_to_display):
    print('text from my_function :: {}'.format(text_to_display))